﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleSample
{
    internal class StringisNullException : Exception
    {
        public StringisNullException() : base("String is null")
        {
        }
    }
}

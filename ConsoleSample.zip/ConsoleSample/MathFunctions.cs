﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleSample
{
    static internal class MathFunctions
    {
        static string Addition(int n1, int n2)
        {

            return $" Sum of two numbers {n1}, {n2} is :{n1 + n2}";
        }
    }


    public class Students
    {
        public string Studentname { get; set; }
        public int Age { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleSample
{
    using System;
    namespace PropertyDemo
    {
        public class Student
        {
            private int _ID;
            private string _Name;
            private int _PassMark = 35;
            public int ID
            {
                set
                {
                    if (value < 0)
                    {
                        throw new Exception("ID value should be greater than zero");
                    }
                    _ID = value;
                }
                get
                {
                    return _ID;
                }
            }
            public string Name
            {
                set
                {
                    if (string.IsNullOrEmpty(value))
                    {
                        throw new Exception("Name should not be empty");
                    }
                    _Name = value;
                }
                get
                {
                    return string.IsNullOrEmpty(_Name) ? "No Name" : _Name;
                }
            }
            public int PassMark
            {
                get
                {
                    return _PassMark;
                }
            }
        }
        
    }
}

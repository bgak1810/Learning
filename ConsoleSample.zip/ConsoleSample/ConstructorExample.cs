﻿using Microsoft.SqlServer.Server;
using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace ConsoleSample
{
    public class ConstructorExample
    {
        int num;
        string _name;int age;
        static string _name;
        static int _age;
        internal ConstructorExample()
        {
            Console.WriteLine("--------------------");
            Console.WriteLine("Default Constructor called here");
            num = 100;
            num += 10;
        }


        internal ConstructorExample(ConstructorExample obj)
        {
            Console.WriteLine("--------------------");
            Console.WriteLine("Copy Constructor called here");
            obj.name = "raja";
            obj.age = 33;
            this.name = obj.name;
            this.age = obj.age;
        }

        internal ConstructorExample(string name,int age)
        {
            Console.WriteLine("--------------------");
            Console.WriteLine("Parameter Constructor called here");
            _name= name;
            this.age = age;
        }
        internal ConstructorExample(string name)
        {
            Console.WriteLine("--------------------");
            Console.WriteLine("Parameter Constructor called here");
            this.name = name;
           
        }

        static ConstructorExample()
        {
            Console.WriteLine("--------------------");
            Console.WriteLine("Static Constructor called here");
            ConstructorExample._name = "Kumar";
            ConstructorExample._age = 30;



        }

        internal int show()
        {
           Console.WriteLine("Your name is {0} and age is {1}",this.name,this.age);
            return num;
        }
        internal void showstatic()
        {
            Console.WriteLine("Your name is {0} and age is {1}", ConstructorExample._name, ConstructorExample._age);
        }
        ~ConstructorExample() { Console.WriteLine("Destructor executed");  }

        enum WeekDays
        {
            Monday,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday
        }
    }
}

﻿
using ConsoleSample.PropertyDemo;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace ConsoleSample // this is our namespace with class library of Program
{
    public class Program //class defined with an object Program
    {
        static string name = "raj"; // string attribute / property with its identifier (Name)
        static int age = 20; //integer attribute/ property with its identifier (Age)
        static List<Students> newlist = new List<Students>(4);
        static void Main(string[] args)
        {
            float f = 100.80f;
            double d = 1.2;
            decimal c = 100.30M;

            //Console.WriteLine(f);
            //Console.WriteLine(d);

            //int i = 100; // initialization

            //int k = 0; k += i;

            ////i++; // i incremented by one. It is post increment

            //int j = i++;

            //Console.WriteLine("The value of i is {0}{1}{1}", i, j);

            //// Console.ReadLine();
            //Console.WriteLine("The value of i is {0}", i);

            //int n = 10;
            ////n =+10;
            ////Console.WriteLine(n);
            ////i = 2;
            //n *= 3;
            ////n /=2;
            //Console.WriteLine(n);

            //int n1 = 100, n2 = 10;
            //string g = (n2 < n1) ? Convert.ToString(n1 / n2) : "Error";

            //int c1 = (n2 < n1) ? (n1 / n2) : -1;

            //Console.WriteLine($"outptu is {g}{c1}");




            /*
             * Example 1
             EnterData("Raj", 30);

            Example 2 // Primitive types
            byte b1 = 66;
            float f = 1.2f;
            double d = 1.2;
            decimal c = 1.3m;
            //You cannot store negative number using byte data type.
            //The following statement will give compile time error
            //byte b2 = -100;
            //The following Statement will give compile time error
            //The maximum value you can store in a byte variable is 255
            //byte b3 = 256;
            Console.WriteLine($"Decimal: {b1}");
            Console.WriteLine($"ASCII Equivalent Character of {b1} is {(char)b1}");

            Console.WriteLine("------Bytes-------");
            Console.WriteLine($"Byte Min Value:{byte.MinValue} and Max Value:{byte.MaxValue}");
            Console.WriteLine($"Byte Size:{sizeof(byte)} Byte");
            Console.WriteLine($"SByte Min Value:{sbyte.MinValue} and Max Value:{byte.MaxValue}");
            Console.WriteLine($"SByte Size:{sizeof(sbyte)} Byte");
            Console.WriteLine("------Integers-------");
            Console.WriteLine($"Min Int16 value {Int16.MinValue} Max Value {Int16.MaxValue}");

            Console.WriteLine($"Min Int32 value {Int32.MinValue} Max Value {Int32.MaxValue}");
            Console.WriteLine($"Min Int64 value {Int64.MinValue} Max Value {Int64.MaxValue}");
            Console.WriteLine();

            Console.WriteLine($"Short int Min value :{short.MinValue} and Max value:{short.MaxValue}");
            Console.WriteLine($"Long int Min value :{long.MinValue} and Max value:{long.MaxValue}");
            Console.WriteLine($"int Min value :{int.MinValue} and Max value:{int.MaxValue}");
            Console.WriteLine();

            Console.WriteLine($" Single Max Value {Single.MinValue} and Max value:{Single.MaxValue}");
            Console.WriteLine($"double Min value :{double.MinValue} and Max value:{double.MaxValue}");

            Console.WriteLine($"float value :{float.MinValue} and Max value:{float.MaxValue}");
            Console.WriteLine($"decimal value :{decimal.MinValue} and Max value:{decimal.MaxValue}");

            Console.WriteLine("Numeric Data type");
            Console.WriteLine($"float value :{f}");
            Console.WriteLine($"double value :{d}");
            Console.WriteLine($"decimal value :{c}");

            Console.WriteLine();
            Console.WriteLine("Comparision");
            Stopwatch stopwatch1 = new Stopwatch();
            stopwatch1.Start();
            for (int i = 0; i <= 10000000; i++)
            {
                short s1 = 100;
                short s2 = 100;
                short s3 = 100;
            }
            stopwatch1.Stop();
            Console.WriteLine($"short took : {stopwatch1.ElapsedMilliseconds} MS");
            Stopwatch stopwatch2 = new Stopwatch();
            stopwatch2.Start();
            for (int i = 0; i <= 10000000; i++)
            {
                decimal s1 = 100;
                decimal s2 = 100;
                decimal s3 = 100;
            }
            stopwatch2.Stop();
            Console.WriteLine($"decimal took : {stopwatch2.ElapsedMilliseconds} MS");


            Example 3 - Converstions
            ConversionExample();

            Example 4 - parsing
             ParsingExample();

            Example 5 - Reference and Value types
            Value type
             Valuetypes();
            Reference 
             ReferenceTypes();

            Passbyvalue
             EnterData("Raj", 30);
            passbyreference
             Passbyref(ref name, ref age);
            Console.WriteLine(name);
            PassbyOut(out name);

            ConversionExample(); */
            //stringtypes();
            //Tuplefun();
            //ParsingExample();
            //PassbyOut(out name);
            //Bodmas();
            //CtoF();

            // DateFunctionality();
            //Dividebyzero();


            //string std = null;

            //try
            //{
            //    nullexception(std);

            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            constructorexample();

            //SquareofaNumber();

            //Collectstudents();
            //CollectionCheck();
            //findspaces();
            //sumofnumbers();
            //factorial();
            //decimal fact= recursivefactorial(5);
            // Console.WriteLine("The factorial of 5! is  {0}", fact);

            //swap();
            // Fibonacci();
            //stringreplace();
            //Datetimefun();
            //



            //loopcheck();
            //Console.WriteLine(name);
            //stringbuilderfun();

            #region properties
            /*try
            {
                Calculator calculator = new Calculator();
            calculator.SetNumber1 = 100; calculator.SetNumber2 = 200;
            calculator.Add();
            Console.WriteLine($"The Sum is: {calculator.GetResult}");
           

                Student student = new Student();
                student.ID = 101;
                student.Name = "Pranaya";

                Console.WriteLine($"ID = {student.ID}");
                Console.WriteLine($"Name = {student.Name}");
                Console.WriteLine($"Pass Mark = {student.PassMark}");

                Student student1 = new Student();
                student.ID = 101;
                student.Name = "Pranaya";

                Console.WriteLine($"ID = {student.ID}");
                Console.WriteLine($"Name = {student.Name}");
                Console.WriteLine($"Pass Mark = {student.PassMark}");

                Student student2 = student1;

                Console.WriteLine($"equal to operator{student == student1}");
                Console.WriteLine($"equals operator{student.Equals(student1)}");
                Console.WriteLine($"equal to operator{student2 == student1}");
                Console.WriteLine($"equals operator{student2.Equals(student1)}");


                Console.WriteLine($"equal to operator{student2.Name == student1.Name}");
                Console.WriteLine($"equals operator{student2.Name.Equals(student1.Name)}");

                int number1 = 100; string number2="100";
                Console.WriteLine($"equal to operator{number1.ToString() == number2}");
                Console.WriteLine($"equals operator{number1.Equals(number2)}");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }*/
            #endregion


            //int xvalue = 100, yvalue = xvalue;
            //Console.WriteLine($"{ xvalue},{ yvalue}");

            //xvalue = 200;
            //Console.WriteLine($"{xvalue},{yvalue}");
            //Dynamicvariable();
            Console.ReadKey();
        }

        static void Datetimefun()
        {
            DateTime inputDate = new DateTime();
            Console.WriteLine("Enter your date of birth in format YYYY-MM-DD");
            inputDate = DateTime.Parse(Console.ReadLine());
            TimeSpan difference = DateTime.Now - Convert.ToDateTime(inputDate);
            Console.WriteLine($"your age is {difference.Days / 365}");



            TimeSpan X = DateTime.Now.Subtract(Convert.ToDateTime(inputDate));
            Console.WriteLine(X);
        }
        static void stringreplace()
        {

            string myString = "W3resource";
            string myOutput = string.Empty;
            Console.WriteLine(myString.Substring(myString.Length - 1) + myString.Substring(1, myString.Length - 2) + myString.Substring(0, 1));

            string myWords = "hello How are you?";
            for (int i = myWords.Length - 1; i >= 0; i--)
            {

                if (myWords.Substring(i, 1) == " ")
                {
                    myOutput = myOutput + myWords.Substring(i, myWords.Length - i);
                }
                //myOutput += myWords[i];
            }
            TextInfo ttc = CultureInfo.CurrentCulture.TextInfo;
            Console.WriteLine(ttc.ToTitleCase(myOutput));

            Console.WriteLine();

        }

        static void findspaces()
        {
            string abcd = "how are you?";
            int spcount = 0;
            string str1 = "";

            for (int i = 0; i < abcd.Length; i++)
            {
                if (abcd[i].ToString() == " ") spcount++;
                //str1 = abcd.Substring(i, 1);
                //if (str1 == " ")
                //    spcount++;
            }

            Console.WriteLine($"no of space :{spcount}");

        }

        static void sumofnumbers()
        {
            int n = 3;
            double x = 0;
            for (int i = 1; i <= n; i++)
            {
                x = x + i;
            }
            Console.WriteLine($"sum of {n} numbers is :{x}");
        }

        static void factorial()
        {
            int n = 5;
            double x = 1;
            for (int i = 1; i <= n; i++)
            {
                x = x * i;
            }
            Console.WriteLine($"Factorial of {n} is :{x}");
        }

        static decimal recursivefactorial(int n1)
        {

            if (n1 == 0)
            {
                return 1;
            }
            // Recursive call: the method calls itself
            else
            {
                return n1 * recursivefactorial(n1 - 1);
            }
        }

        static void swap()
        {
            int a = 10, b = 20, c = 0;
            c = a; // 10
            a = b;//20
            b = c;//10
            Console.WriteLine($"a is {a},{b}");
        }


        static void Fibonacci()
        {
            int n = 5;
            string myout = string.Empty;
            int num1 = 0, num2 = 1, temp = 0;
            for (int i = 0; i < n; i++)
            {
                num1 = 0;
                num2 = 1;
                for (int j = 0; j < i; j++)
                {
                    temp = num1;
                    num1 = num2;
                    num2 = temp + num2;
                }
                if (myout.Length == 0)
                    myout = num2.ToString();
                else
                    myout += " " + num2.ToString();
            }

            Console.WriteLine($"fib series is {myout}");
        }

        static void Collectstudents()
        {
            int age = 0; string sname = string.Empty;

            Console.WriteLine("Enter your age");
            age = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter your name");
            sname = Console.ReadLine();

            newlist.Add(new Students { Age = age, Studentname = sname });

            Console.WriteLine("Do you want to continue entering the records : Y/N");
            char choice = Convert.ToChar(Console.ReadLine());
            if (choice == 'Y')
                Collectstudents();
            else
                Showstudents();
        }

        private static void Showstudents()
        {
            foreach (Students item in newlist)
            {
                Console.WriteLine($"Student name :{item.Studentname}, Age :{item.Age}");
            }
        }

        private static void CollectionCheck()
        {
            //Generic list
            Console.WriteLine("Generic List");
            Console.WriteLine("------------");
            Console.WriteLine("List");
            var list = new List<Students>();

            /* 1st way of adding to list */
            Students sitem = new Students();
            sitem.Age = 1;
            sitem.Studentname = "Adarsh";
            list.Add(sitem);
            /* 2nd way of adding to list */
            list.Add(new Students { Age = 10, Studentname = "Kumar" });

            /* 3rd way of adding to list */
            List<Students> newlist = new List<Students>(4);
            newlist.Add(new Students { Age = 14, Studentname = "Raja" });
            newlist.Add(new Students { Age = 14, Studentname = "Raja" });
            newlist.Add(new Students { Age = 14, Studentname = "Raja" });

            foreach (Students items in list)
            {
                Console.WriteLine($"hello {items.Studentname},{items.Age}");
            }
            foreach (Students items in newlist)
            {
                Console.WriteLine($"hello {items.Studentname},{items.Age}");
            }


            Console.WriteLine("SortedDictionary objects");
            SortedDictionary<string, string> mylist2 = new SortedDictionary<string, string>();

            mylist2.Add("z", "raj");
            mylist2.Add("a", "krishna");
            mylist2.Add("d", "Adarsh");

            Console.WriteLine(mylist2.Count);
            foreach (KeyValuePair<string, string> item in mylist2)
            {
                Console.WriteLine($"{item.Key},{item.Value}");
            }


            Console.WriteLine("SortedList objects");
            SortedList<int, string> keyValuePairs = new SortedList<int, string>();
            keyValuePairs.Add(1, "z");
            keyValuePairs.Add(2, "b");
            keyValuePairs.Add(31, "A");

            foreach (var item in keyValuePairs)
            {
                Console.WriteLine($"{item.Key},{item.Value} ");
            }

            Console.WriteLine("Dictionary objects");
            Dictionary<int, string> dictValuePairs = new Dictionary<int, string>();
            dictValuePairs.Add(1, "z");
            dictValuePairs.Add(2, "b");
            dictValuePairs.Add(31, "A");

            foreach (KeyValuePair<int, string> item in dictValuePairs)
            {
                Console.WriteLine($"{item.Key},{item.Value} ");
            }

            Queue<int> queue = new Queue<int>();
            queue.Enqueue(1);
            queue.Enqueue(2);
            foreach (var item in queue)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Stack objects");
            Stack<string> strings = new Stack<string>();
            strings.Push("z");
            strings.Push("kumar");
            strings.Push("Raja");
            foreach (string item in strings)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("-------------------------------------------");
            //non generic list
            Console.WriteLine("Non Generic List");
            Console.WriteLine("------------");
            Console.WriteLine("ArrayList");
            ArrayList mylist = new ArrayList(2);

            mylist.Add(1);
            mylist.Add(true);
            mylist.Add(new Students { Age = 14, Studentname = "Raja" });
            mylist.Add("Adarsh");

            foreach (var items in mylist)
            {
                Console.WriteLine($" {items}");
            }
            Console.WriteLine("Stack");
            Stack stack = new Stack();
            stack.Push("z");
            stack.Push("A");
            stack.Push(1);
            stack.Push(true);
            var top = stack.Peek();

            Console.WriteLine(top.ToString());

            foreach (object item in stack)
            {
                Console.WriteLine(item);
            }


        }

        private static void SquareofaNumber()
        {
            int n = 10;
            int powerof = 4;
            double ot = 1;

            for (int i = 1; i <= powerof; i++)
            {
                ot *= n;
            }
            Console.WriteLine($"output is :{ot}");
            Console.WriteLine(Math.Pow(n, 4));
        }

        private static void DateFunctionality()
        {
            DateTime dt1 = new DateTime(2022, 02, 14);
            Console.WriteLine(dt1.ToShortDateString());

            Console.WriteLine(DateTime.DaysInMonth(2023, 10));

        }

        static void CtoF()
        {
            try
            {
                int[] x1 = { 1, 2, 3 };
                x1.SetValue("hello", 3);
                Console.WriteLine(x1);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.ToString());
            }

            float largefloat = 9;
            float smallfloat = 5;
            float x = largefloat % smallfloat;
            Console.WriteLine($"asasdf {x}");
            float y = largefloat / smallfloat;
            Console.WriteLine(y);

            Console.WriteLine("Enter the Celsius");
            int c = Convert.ToInt16(Console.ReadLine());

            float O = c * y + 32;

            Console.WriteLine(O);
        }
        private static void Bodmas()
        {
            //Brackets
            //Order
            //Division
            //Multiplication
            //Addition
            //Subtraction
            System.Console.WriteLine(2 + 15 / 6 * 2 - 7 % 2);
        }

        private static void PassbyOut(out string name)
        {
            name = "Rajababu";
            int x = 0;
            Console.WriteLine($"x compare:{x.CompareTo(0)}");
        }
        private static void stringtypes()
        {
            long x = 1000000000000000000;

            string abc = string.Empty;
            Console.WriteLine($"stringtypes is:{abc.ToString()}");
        }

        /*     
      public static void ConversionExample()
      {
         int numInt = 0;
         //Get type of numInt
         Type numIntType = numInt.GetType();
         // Implicit Conversion
         double numDouble = 1.2;

         //Get type of numDouble
         Type numDoubleType = numDouble.GetType();
         // Value Before Conversion
         Console.WriteLine($"numInt value: {numInt}");
         Console.WriteLine($"numInt Type: {numIntType}");
         Console.WriteLine($"Int Size: {sizeof(int)} Bytes");

                  // Value After Conversion
                  Console.WriteLine($"numDouble value: {numDouble}");
         Console.WriteLine($"numDouble Type: {numDoubleType}");
         Console.WriteLine($"double Size: {sizeof(double)} Bytes");
         Console.ReadKey();

      }

      class Employee
      {
         public string Empname { get; set; }
         public int Age { get; set; }
      }
      struct Employees
      {
         public string Empname { get; set; }
         public int Age { get; set; }
      }
      private static void ReferenceTypes()
      {
         Employee emp = new Employee();
         emp.Empname = "Adarsh";emp.Age = 23;
         Employee emp2 = emp;
         Employee emp3 = emp;
        emp=null;
         Console.WriteLine("Reference Types");
         Console.WriteLine($"emp object data :Name -{emp.Empname} Age - {emp.Age}");
         emp.Age = 25;
         Console.WriteLine($"emp object data :Name -{emp.Empname} Age - {emp.Age}");
         Console.WriteLine($"emp2 object data :Name -{emp2.Empname} Age - {emp2.Age}");
         Console.WriteLine($"emp3 object data :Name -{emp3.Empname} Age - {emp3.Age}");
      }

      private static void Valuetypes()
      {
         Employees emp = new Employees();
         emp.Empname = "Adarsh"; emp.Age = 23;
         Employees emp2 = emp;
         Employees emp3 = emp;
         Console.WriteLine("Value Types");
         Console.WriteLine($"emp object data :Name -{emp.Empname} Age - {emp.Age}");
         emp.Age = 25;
         Console.WriteLine($"emp object data :Name -{emp.Empname} Age - {emp.Age}");
         Console.WriteLine($"emp2 object data :Name -{emp2.Empname} Age - {emp2.Age}");
         Console.WriteLine($"emp3 object data :Name -{emp3.Empname} Age - {emp3.Age}");
      }*/

        private static void ParsingExample()
        {
            string str = "100";
            //Converting string to int type
            int i = int.Parse(str);
            Console.WriteLine("Converting string to int type");
            Console.WriteLine($"output of value i is :{i}");
            Console.WriteLine();

            string str2 = "Welcome";
            //Converting string to int type
            bool o = int.TryParse(str2, out int I1);
            Console.WriteLine($"bool value {o}");
            if (o) { Console.WriteLine($"Original String value: {str2} and Converted int value: {I1}"); }
            else
            { Console.WriteLine($"Try Parse Failed to Convert {str2} to integer"); }

            Console.WriteLine();
        }
        /*
      public static void EnterData(string name,uint age)//Method which return a string
      {
         Console.WriteLine($"Your name is {name} and age is {age}"); //Formatters with the return variables

      }
              private static void Passbyref(ref string name, ref int age)
              {
                  name = "Raja";
                  age = 45;
              }
      */

        private static void Tuplefun()
        {
            var items = (1, 2, 3, 4, 5, 6, 8);
            Console.WriteLine(items.Item5);
        }

        static void loopcheck()
        {
            int mulitiplicationNumber, startNumber, endNumber;

            Console.WriteLine("Enter the Multiplication Number");
            mulitiplicationNumber = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter the Start Number");
            startNumber = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter the End Number");
            endNumber = Convert.ToInt16(Console.ReadLine());


            do
            {
                Console.WriteLine($"{mulitiplicationNumber} * {startNumber} = {mulitiplicationNumber * startNumber}");
                startNumber++;

            } while (startNumber <= endNumber);


        }

        static void Dividebyzero()
        {
            int div = 100, ds = 0;
            Console.WriteLine(div / ds);
        }

        static void nullexception(string str)
        {

            if (str == null)
                throw new StringisNullException();
            //throw new Exception("string is null");
            else
                Console.WriteLine($"string value is :{str.ToString()}");

        }

        static void constructorexample()
        {
            ConstructorExample cn = new ConstructorExample(); //Default Constructor
            Console.WriteLine($"value of k :{cn.show()}");

             ConstructorExample paramcn = new ConstructorExample("Adarsh", 44); // parameterised constructor
             paramcn.show();

             ConstructorExample cn1 = new ConstructorExample(paramcn); //copy constructor
             cn1.show(); 

            ConstructorExample staticcn = new ConstructorExample(); //static constructor
            staticcn.showstatic();            


            //StringBuilder sbAmout = new StringBuilder("Your total amount is ");
            //sbAmout.AppendFormat("{0:c} ", 25);

            //Console.WriteLine(sbAmout);



        }

        private static void Dynamicvariable()
        {
            dynamic MyDynamicVar = 100;
            Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());

            MyDynamicVar = "Hello World!!";
            Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());

            MyDynamicVar = true;
            Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());

            MyDynamicVar = DateTime.Now;
            Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());
        }

        static void stringbuilderfun()
        {
            string[] str = new string[] { "hello", "how", "are", "you" };
            StringBuilder stringBuilder = new StringBuilder();
            string mys = string.Empty;
            foreach (string s in str)
            {
                mys += s + "\n";
                stringBuilder.Append(s);
            }
            Console.WriteLine($" string {mys} , strinbuilder {stringBuilder}");

            foreach (var item in Enum.GetValues(typeof(WeekDays)))
            {
                Console.WriteLine(item);
            }
        }

        internal enum WeekDays
        {
            Monday,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday
        }

    }
}


